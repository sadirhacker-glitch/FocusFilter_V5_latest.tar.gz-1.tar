package com.focusfilter.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.focusfilter.FocusFilterApplication
import com.focusfilter.model.FocusModeType

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val app   = context.applicationContext as FocusFilterApplication
        val prefs = app.preferencesManager
        if (!prefs.startOnBoot) return
        val prevMode = prefs.activeModeType
        if (prevMode == FocusModeType.SLEEP.name) {
            prefs.isFocusEnabled = true
            prefs.activeModeType = prevMode
        } else {
            prefs.isFocusEnabled = false
            prefs.activeModeType = FocusModeType.NONE.name
        }
    }
}
