package com.focusfilter.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.focusfilter.data.db.converters.KeywordsConverter
import com.focusfilter.data.db.dao.FilteredNotificationDao
import com.focusfilter.data.db.dao.FocusModeDao
import com.focusfilter.data.db.dao.RuleDao
import com.focusfilter.data.db.dao.SenderReputationDao
import com.focusfilter.data.db.entities.FilteredNotification
import com.focusfilter.data.db.entities.FocusMode
import com.focusfilter.data.db.entities.Rule
import com.focusfilter.data.db.entities.SenderReputation
import com.focusfilter.data.keyword.KeywordSafelist
import com.focusfilter.data.keyword.KeywordSafelistDao
import com.focusfilter.model.NotificationAction
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [FilteredNotification::class, Rule::class, FocusMode::class, KeywordSafelist::class, SenderReputation::class],
    version = 8,
    exportSchema = false
)
@TypeConverters(KeywordsConverter::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun filteredNotificationDao(): FilteredNotificationDao
    abstract fun ruleDao(): RuleDao
    abstract fun focusModeDao(): FocusModeDao
    abstract fun keywordSafelistDao(): KeywordSafelistDao
    abstract fun senderReputationDao(): SenderReputationDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE filtered_notifications ADD COLUMN blockReason TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE filtered_notifications ADD COLUMN isOverride INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE focus_modes ADD COLUMN displayName TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE focus_modes ADD COLUMN description TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE focus_modes ADD COLUMN iconName TEXT NOT NULL DEFAULT 'ic_shield'")
                database.execSQL("ALTER TABLE focus_modes ADD COLUMN scheduleEnabled INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE focus_modes ADD COLUMN scheduleStart TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE focus_modes ADD COLUMN scheduleEnd TEXT NOT NULL DEFAULT ''")
                database.execSQL("ALTER TABLE focus_modes ADD COLUMN isCustom INTEGER NOT NULL DEFAULT 0")
                database.execSQL("UPDATE focus_modes SET displayName='Gaming Mode', description='Block distractions, allow important', iconName='ic_gamepad' WHERE type='GAMING'")
                database.execSQL("UPDATE focus_modes SET displayName='Work Mode', description='Prioritize work apps and important alerts', iconName='ic_briefcase' WHERE type='WORK'")
                database.execSQL("UPDATE focus_modes SET displayName='Sleep Mode', description='Only emergencies will break through', iconName='ic_moon' WHERE type='SLEEP'")
                database.execSQL("UPDATE focus_modes SET displayName='Custom Mode', description='Your own rules and filters', iconName='ic_settings', isCustom=1 WHERE type='CUSTOM'")
                database.execSQL("""INSERT OR IGNORE INTO focus_modes (type,displayName,description,iconName,isActive,dndEnabled,allowedApps,allowedContacts,allowedKeywords,blockedKeywords,defaultAction,isCustom,scheduleEnabled,scheduleStart,scheduleEnd) VALUES ('STUDY','Study Mode','Deep focus for learning and studying','ic_timer',0,1,'','','alarm,urgent,emergency,call','','BLOCK',0,0,'','')""")
                database.execSQL("""INSERT OR IGNORE INTO focus_modes (type,displayName,description,iconName,isActive,dndEnabled,allowedApps,allowedContacts,allowedKeywords,blockedKeywords,defaultAction,isCustom,scheduleEnabled,scheduleStart,scheduleEnd) VALUES ('EXAM','Exam Mode','Maximum focus — only emergencies pass','ic_block',0,1,'','','emergency,urgent,alarm','','BLOCK',0,0,'','')""")
                database.execSQL("""INSERT OR IGNORE INTO focus_modes (type,displayName,description,iconName,isActive,dndEnabled,allowedApps,allowedContacts,allowedKeywords,blockedKeywords,defaultAction,isCustom,scheduleEnabled,scheduleStart,scheduleEnd) VALUES ('DEEP_FOCUS','Deep Focus','Zero interruptions — you are in the zone','ic_shield',0,1,'','','emergency,alarm','','BLOCK',0,0,'','')""")
                database.execSQL("""INSERT OR IGNORE INTO focus_modes (type,displayName,description,iconName,isActive,dndEnabled,allowedApps,allowedContacts,allowedKeywords,blockedKeywords,defaultAction,isCustom,scheduleEnabled,scheduleStart,scheduleEnd) VALUES ('READING','Reading Mode','Quiet time for books and articles','ic_check_circle',0,0,'','','urgent,emergency,call','','BLOCK',0,0,'','')""")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE focus_modes ADD COLUMN silenceCalls INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE focus_modes ADD COLUMN isBuiltIn INTEGER NOT NULL DEFAULT 0")
                database.execSQL("UPDATE focus_modes SET isBuiltIn=1 WHERE type IN ('GAMING','WORK','SLEEP','CUSTOM','STUDY','EXAM','DEEP_FOCUS','READING')")
                database.execSQL("UPDATE focus_modes SET dndEnabled=1 WHERE type='WORK'")
                database.execSQL("UPDATE focus_modes SET silenceCalls=0 WHERE type='SLEEP'")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                val cursor = database.query("SELECT type, allowedKeywords, blockedKeywords FROM focus_modes")
                while (cursor.moveToNext()) {
                    val type        = cursor.getString(0) ?: continue
                    val allowedCsv  = cursor.getString(1) ?: ""
                    val blockedCsv  = cursor.getString(2) ?: ""
                    val allowedJson = csvToJsonArray(allowedCsv)
                    val blockedJson = csvToJsonArray(blockedCsv)
                    database.execSQL(
                        "UPDATE focus_modes SET allowedKeywords=?, blockedKeywords=? WHERE type=?",
                        arrayOf(allowedJson, blockedJson, type)
                    )
                }
                cursor.close()
            }

            private fun csvToJsonArray(csv: String): String {
                if (csv.isBlank()) return "[]"
                if (csv.trimStart().startsWith('[')) return csv
                val items = csv.split(",")
                    .map { it.trim() }
                    .filter { it.isNotBlank() }
                    .joinToString(",") { "\"${it.replace("\\", "\\\\").replace("\"", "\\\"")}\"" }
                return "[$items]"
            }
        }

        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "ALTER TABLE filtered_notifications ADD COLUMN isPermanent INTEGER NOT NULL DEFAULT 0"
                )
            }
        }

        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "ALTER TABLE filtered_notifications ADD COLUMN sbnKey TEXT"
                )
            }
        }

        private val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS sender_reputation (
                        packageName TEXT PRIMARY KEY NOT NULL,
                        allowCount INTEGER NOT NULL DEFAULT 0,
                        blockCount INTEGER NOT NULL DEFAULT 0,
                        lastSeen INTEGER NOT NULL DEFAULT 0
                    )
                """)
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    """CREATE TABLE IF NOT EXISTS keyword_safelist (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        keyword TEXT NOT NULL,
                        addedAt INTEGER NOT NULL
                    )"""
                )
                // Strip emojis from built-in mode display names
                database.execSQL("UPDATE focus_modes SET displayName='Gaming Mode'   WHERE type='GAMING'     AND (displayName LIKE '🎮%' OR displayName LIKE '%Gaming Mode')")
                database.execSQL("UPDATE focus_modes SET displayName='Work Mode'     WHERE type='WORK'       AND (displayName LIKE '💼%' OR displayName LIKE '%Work Mode')")
                database.execSQL("UPDATE focus_modes SET displayName='Sleep Mode'    WHERE type='SLEEP'      AND (displayName LIKE '😴%' OR displayName LIKE '%Sleep Mode')")
                database.execSQL("UPDATE focus_modes SET displayName='Custom Mode'   WHERE type='CUSTOM'     AND (displayName LIKE '%Custom Mode')")
                database.execSQL("UPDATE focus_modes SET displayName='Study Mode'    WHERE type='STUDY'      AND (displayName LIKE '%Study Mode')")
                database.execSQL("UPDATE focus_modes SET displayName='Exam Mode'     WHERE type='EXAM'       AND (displayName LIKE '%Exam Mode')")
                database.execSQL("UPDATE focus_modes SET displayName='Deep Focus'    WHERE type='DEEP_FOCUS' AND (displayName LIKE '%Deep Focus')")
                database.execSQL("UPDATE focus_modes SET displayName='Reading Mode'  WHERE type='READING'    AND (displayName LIKE '%Reading Mode')")
                // Ensure silenceCalls=false for all built-in modes except none
                database.execSQL("UPDATE focus_modes SET silenceCalls=0 WHERE isBuiltIn=1")
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "focusfilter.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8)
                    .build()

                INSTANCE = instance

                CoroutineScope(Dispatchers.IO).launch {
                    ensureBuiltInModes(instance.focusModeDao())
                    seedDefaultRules(instance.ruleDao())
                }

                instance
            }
        }

        suspend fun ensureBuiltInModes(dao: FocusModeDao) {
            val existing      = dao.getAllModesList()
            val existingTypes = existing.map { it.type }.toSet()

            val builtInModes = listOf(
                FocusMode(type = "GAMING",     displayName = "Gaming Mode",   description = "Block distractions, allow important", iconName = "ic_gamepad",     dndEnabled = true,  silenceCalls = false, allowedKeywords = listOf("urgent","emergency","payment","OTP","verify"), defaultAction = NotificationAction.BLOCK.name, isBuiltIn = true),
                FocusMode(type = "WORK",       displayName = "Work Mode",     description = "Prioritize work apps and important alerts", iconName = "ic_briefcase",  dndEnabled = true,  silenceCalls = false, allowedKeywords = listOf("meeting","call","urgent","payment","OTP","bank"), defaultAction = NotificationAction.BLOCK.name, isBuiltIn = true),
                FocusMode(type = "SLEEP",      displayName = "Sleep Mode",    description = "Only emergencies will break through", iconName = "ic_moon",        dndEnabled = true,  silenceCalls = false, allowedKeywords = listOf("emergency","urgent","alarm"), defaultAction = NotificationAction.BLOCK.name, isBuiltIn = true),
                FocusMode(type = "CUSTOM",     displayName = "Custom Mode",   description = "Your own rules and filters", iconName = "ic_settings",    dndEnabled = false, silenceCalls = false, defaultAction = NotificationAction.ALLOW.name, isBuiltIn = true),
                FocusMode(type = "STUDY",      displayName = "Study Mode",    description = "Deep focus for learning and studying", iconName = "ic_timer",      dndEnabled = true,  silenceCalls = false, allowedKeywords = listOf("alarm","urgent","emergency","call"), defaultAction = NotificationAction.BLOCK.name, isBuiltIn = true),
                FocusMode(type = "EXAM",       displayName = "Exam Mode",     description = "Maximum focus — only emergencies pass", iconName = "ic_block",      dndEnabled = true,  silenceCalls = false, allowedKeywords = listOf("emergency","urgent","alarm"), defaultAction = NotificationAction.BLOCK.name, isBuiltIn = true),
                FocusMode(type = "DEEP_FOCUS", displayName = "Deep Focus",    description = "Zero interruptions — you're in the zone", iconName = "ic_shield",     dndEnabled = true,  silenceCalls = false, allowedKeywords = listOf("emergency","alarm"), defaultAction = NotificationAction.BLOCK.name, isBuiltIn = true),
                FocusMode(type = "READING",    displayName = "Reading Mode",  description = "Quiet time for books and articles", iconName = "ic_check_circle", dndEnabled = false, silenceCalls = false, allowedKeywords = listOf("urgent","emergency","call"), defaultAction = NotificationAction.BLOCK.name, isBuiltIn = true)
            )

            builtInModes.forEach { mode ->
                if (mode.type !in existingTypes) {
                    dao.insertOrReplace(mode)
                } else {
                    val current = existing.find { it.type == mode.type }
                    if (current != null && (!current.isBuiltIn
                            || (mode.type == "WORK"  && !current.dndEnabled))) {
                        dao.insertOrReplace(
                            current.copy(
                                isBuiltIn    = true,
                                displayName  = mode.displayName,
                                silenceCalls = false,
                                dndEnabled   = if (mode.type == "WORK") true else current.dndEnabled
                            )
                        )
                    }
                }
            }
        }

        private suspend fun seedDefaultRules(dao: RuleDao) {
            val existing = dao.getEnabledRules()
            if (existing.isNotEmpty()) return
            val defaultKeywords = listOf("OTP", "bank", "urgent", "verify", "emergency", "payment", "password", "security")
            defaultKeywords.forEach { keyword ->
                dao.insert(Rule(
                    type      = "KEYWORD",
                    value     = keyword.lowercase(),
                    action    = NotificationAction.ALLOW.name,
                    label     = keyword,
                    isEnabled = true,
                    focusModes = "ALL"
                ))
            }
        }
    }
}
