package com.focusfilter.data.keyword

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "keyword_safelist")
data class KeywordSafelist(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val keyword: String,
    val addedAt: Long = System.currentTimeMillis()
)
