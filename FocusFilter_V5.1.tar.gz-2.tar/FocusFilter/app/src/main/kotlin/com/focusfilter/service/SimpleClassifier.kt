package com.focusfilter.service

/**
 * Keyword-based on-device classifier.
 * Entirely local — no network calls, no external SDKs.
 *
 * Label priority (highest → lowest):
 *   otp → payment → bank → delivery → emergency → security →
 *   promo → social → spam → important → games → unknown
 *
 * The [classify(title, body)] override checks the title independently first
 * because the title is the most semantically dense part of a notification.
 */
class SimpleClassifier : NotificationClassifier {

    override fun classify(notificationText: String): String {
        val lower = notificationText.lowercase()
        return when {
            lower.containsAny("otp", "one-time", "one time", "verification code",
                "auth code", "2fa", "two-factor") -> "otp"

            // payment checked before bank — payment keywords are more specific.
            lower.containsAny("payment", "paid", "transaction", "credited", "debited",
                "transfer", "invoice", "receipt") -> "payment"

            lower.containsAny("bank", "account", "balance", "statement", "loan",
                "emi", "credit card", "debit card") -> "bank"

            // delivery — before emergency/promo so courier notifications don't get misclassified.
            lower.containsAny("delivered", "out for delivery", "your package",
                "your order has", "pickup ready", "pick up your", "courier",
                "tracking number", "parcel", "shipment arrives",
                "estimated delivery", "package arrived") -> "delivery"

            lower.containsAny("emergency", "urgent", "critical", "immediately",
                "asap", "sos", "emergency help", "need help now") -> "emergency"

            lower.containsAny("password", "security", "verify", "confirm",
                "suspicious", "unauthorized", "login attempt") -> "security"

            lower.containsAny("offer", "discount", "sale", "% off", "deal",
                "limited time", "coupon", "promo", "cashback", "rewards") -> "promo"

            lower.containsAny("liked", "commented", "followed", "mention",
                "tagged", "story", "reacted", "replied", "shared your") -> "social"

            // bare "free" and bare "win" removed — too many false positives.
            lower.containsAny("spam", "unsubscribe", "click here", "win!",
                "winner", "prize", "claim your free", "you won free",
                "get it free", "congratulations you") -> "spam"

            lower.containsAny("meeting", "call scheduled", "reminder", "task",
                "due", "deadline", "assigned", "project") -> "important"

            lower.containsAny("level up", "achievement", "game over", "match found",
                "your turn", "challenge", "high score", "leaderboard",
                "arena", "quest", "dungeon") -> "games"

            else -> "unknown"
        }
    }

    /**
     * Title-weighted classification: checks the title independently first.
     * If the title yields a confident label, use it — the title is the most
     * semantically dense field and tends to be more deliberate than the body.
     */
    override fun classify(title: String, body: String): String {
        val titleLabel = classify(title)
        if (titleLabel != "unknown") return titleLabel
        return classify("$title $body")
    }

    override fun hasScamSignals(text: String): Boolean {
        val lower = text.lowercase()
        val hasUrl = listOf(
            "bit.ly", "tinyurl", "t.me/", "http://",
            "click here", "tap here", "verify at",
            "login at", "confirm at", "visit now"
        ).any { lower.contains(it) }
        val hasUrgency = listOf(
            "suspended", "verify now", "confirm immediately",
            "act now", "your account will",
            "unusual activity", "unauthorized access",
            "account frozen", "immediate action required"
        ).any { lower.contains(it) }
        return hasUrl || hasUrgency
    }

    private fun String.containsAny(vararg keywords: String): Boolean =
        keywords.any { this.contains(it) }
}
